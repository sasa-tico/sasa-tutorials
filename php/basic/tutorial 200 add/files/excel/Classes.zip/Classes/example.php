<?php

require_once "Classes/PHPExcel.php";

        $tmpfname = "sifarnik2.xlsx";
        $excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
        $excelObj = $excelReader->load($tmpfname);
        $worksheet = $excelObj->getSheet(0);
        $lastRow = $worksheet->getHighestRow();
        
        for ($row = 3; $row <= $lastRow; $row++) {
            $sifra = $worksheet->getCell('B'.$row)->getValue();
            $naziv = $worksheet->getCell('C'.$row)->getValue());

        }


?>